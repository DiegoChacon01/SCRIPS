#!/bin/bash

saludo () {
  echo "Hola $1"
}
saludo "Jose Antonio"

