#!/bin/bash
hola_mundo () {
   echo 'Hola, mundo'
}

hola_mundo
