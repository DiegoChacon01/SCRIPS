#! /bin/bash
echo -n "HOLA": "
read x 
echo "Has escrito $x"
echo -n "Escribe 2 palabras": "
read x y 
echo "Primera palabra $x; SEgunda palabra $y"
